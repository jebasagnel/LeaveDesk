package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.LeaveDeskRepository
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter

@Composable
fun CompanyCalendarScreen(
  repository: LeaveDeskRepository,
  modifier: Modifier = Modifier
) {
  val currentUser by repository.currentUser.collectAsState()
  val holidays by repository.companyHolidays.collectAsState()
  val groupEvents by repository.groupEvents.collectAsState()
  val leaveRequests by repository.leaveRequests.collectAsState()

  var currentMonth by remember { mutableStateOf(YearMonth.now()) }
  var selectedDate by remember { mutableStateOf(LocalDate.now()) }

  // TL Override Dialog
  var showTlOverrideDialog by remember { mutableStateOf(false) }
  var overrideTitle by remember { mutableStateOf("") }
  var overrideRemark by remember { mutableStateOf("") }
  var isWorkingDayOverride by remember { mutableStateOf(false) }

  if (showTlOverrideDialog) {
    AlertDialog(
      onDismissRequest = { showTlOverrideDialog = false },
      title = { Text("Group Calendar Event / Override", fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("Target Date: ${selectedDate.format(DateTimeFormatter.ofPattern("MMM dd, yyyy"))}", fontWeight = FontWeight.SemiBold)
          OutlinedTextField(
            value = overrideTitle,
            onValueChange = { overrideTitle = it },
            label = { Text("Event Title *") },
            placeholder = { Text("e.g. Critical Milestone Delivery") },
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = overrideRemark,
            onValueChange = { overrideRemark = it },
            label = { Text("Remark *") },
            modifier = Modifier.fillMaxWidth()
          )
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Treat as Working Day override", fontSize = 12.sp)
            Switch(
              checked = isWorkingDayOverride,
              onCheckedChange = { isWorkingDayOverride = it }
            )
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val success = repository.addGroupCalendarEvent(
              tl = currentUser,
              date = selectedDate,
              title = overrideTitle,
              remark = overrideRemark,
              isWorkingDayOverride = isWorkingDayOverride
            )
            if (success) {
              showTlOverrideDialog = false
              overrideTitle = ""
              overrideRemark = ""
            }
          },
          enabled = overrideTitle.isNotBlank() && overrideRemark.isNotBlank(),
          colors = ButtonDefaults.buttonColors(containerColor = TeamLeadIndigo)
        ) {
          Text("Save Group Event")
        }
      },
      dismissButton = {
        TextButton(onClick = { showTlOverrideDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }

  // Details of selected date
  val selectedHoliday = remember(holidays, selectedDate) {
    holidays.find { it.date == selectedDate }
  }
  val selectedGroupEvents = remember(groupEvents, selectedDate, currentUser) {
    groupEvents.filter { it.date == selectedDate && it.groupId == currentUser.groupId }
  }
  val approvedLeavesOnDate = remember(leaveRequests, selectedDate) {
    leaveRequests.filter {
      it.status == LeaveStatus.APPROVED && !selectedDate.isBefore(it.startDate) && !selectedDate.isAfter(it.endDate)
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Header & Month Navigator
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = currentMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy")),
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )
      Row {
        IconButton(onClick = { currentMonth = currentMonth.minusMonths(1) }) {
          Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Month")
        }
        IconButton(onClick = { currentMonth = currentMonth.plusMonths(1) }) {
          Icon(Icons.Default.ChevronRight, contentDescription = "Next Month")
        }
      }
    }

    // Weekday headers
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun").forEach { day ->
        Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
          Text(text = day, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
        }
      }
    }

    // Month Grid (Simplified 35-day block)
    val firstDayOfMonth = currentMonth.atDay(1)
    val dayOffset = (firstDayOfMonth.dayOfWeek.value - 1) // 0 for Mon
    val daysInMonth = currentMonth.lengthOfMonth()

    val totalCells = ((dayOffset + daysInMonth + 6) / 7) * 7

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
      for (row in 0 until (totalCells / 7)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          for (col in 0..6) {
            val cellIndex = row * 7 + col
            val dayNum = cellIndex - dayOffset + 1
            if (dayNum in 1..daysInMonth) {
              val date = currentMonth.atDay(dayNum)
              val isSelected = date == selectedDate
              val holiday = holidays.find { it.date == date }
              val hasLeaves = approvedLeavesOnDate.any { it.startDate <= date && it.endDate >= date }

              val isWeekend = date.dayOfWeek == DayOfWeek.SATURDAY || date.dayOfWeek == DayOfWeek.SUNDAY

              val cellColor = when {
                holiday?.type == HolidayType.PUBLIC_HOLIDAY -> Color(HolidayType.PUBLIC_HOLIDAY.colorHex).copy(alpha = 0.15f)
                holiday?.type == HolidayType.COMPANY_CLOSURE -> Color(HolidayType.COMPANY_CLOSURE.colorHex).copy(alpha = 0.15f)
                holiday?.type == HolidayType.OPTIONAL_HOLIDAY -> Color(HolidayType.OPTIONAL_HOLIDAY.colorHex).copy(alpha = 0.15f)
                isWeekend -> NeutralTint.copy(alpha = 0.5f)
                else -> Color.White
              }

              Box(
                modifier = Modifier
                  .weight(1f)
                  .height(44.dp)
                  .padding(2.dp)
                  .clip(RoundedCornerShape(6.dp))
                  .background(if (isSelected) EmployeeTealLight else cellColor)
                  .border(
                    BorderStroke(
                      if (isSelected) 2.dp else 1.dp,
                      if (isSelected) EmployeeTeal else CardBorder
                    ),
                    RoundedCornerShape(6.dp)
                  )
                  .clickable { selectedDate = date },
                contentAlignment = Alignment.Center
              ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                  ) {
                    Text(
                      text = dayNum.toString(),
                      fontSize = 12.sp,
                      fontWeight = if (isSelected || holiday != null) FontWeight.Bold else FontWeight.SemiBold,
                      color = if (holiday != null) Color(holiday.colorHex) else TextPrimary
                    )
                    if (holiday?.isLockedByCeo == true) {
                      Text("🔒", fontSize = 8.sp, modifier = Modifier.padding(start = 2.dp))
                    }
                  }
                  if (holiday != null || hasLeaves) {
                    Box(
                      modifier = Modifier
                        .padding(top = 1.dp)
                        .size(4.dp)
                        .clip(CircleShape)
                        .background(if (holiday != null) Color(holiday.colorHex) else EmployeeTeal)
                    )
                  }
                }
              }
            } else {
              Spacer(modifier = Modifier.weight(1f))
            }
          }
        }
      }
    }

    // Color Legend
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      LegendDot("Public Holiday", Color(HolidayType.PUBLIC_HOLIDAY.colorHex))
      LegendDot("Closure", Color(HolidayType.COMPANY_CLOSURE.colorHex))
      LegendDot("Optional", Color(HolidayType.OPTIONAL_HOLIDAY.colorHex))
      LegendDot("Approved Leave", StatusApprovedGreen)
    }

    // Selected Date Details Card
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      border = BorderStroke(1.dp, CardBorder),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = selectedDate.format(DateTimeFormatter.ofPattern("EEEE, MMMM dd, yyyy")),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
          if (currentUser.role == UserRole.TEAM_LEAD) {
            TextButton(onClick = { showTlOverrideDialog = true }) {
              Text("+ Group Event", fontSize = 11.sp, color = TeamLeadIndigo)
            }
          }
        }

        if (selectedHoliday != null) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = Color(selectedHoliday.colorHex).copy(alpha = 0.12f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(8.dp)) {
              Text(
                text = "${selectedHoliday.type.displayName}: ${selectedHoliday.title}",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(selectedHoliday.colorHex)
              )
              if (selectedHoliday.remark.isNotBlank()) {
                Text(selectedHoliday.remark, fontSize = 11.sp, color = TextSecondary)
              }
              if (selectedHoliday.isLockedByCeo) {
                Text("🔒 Locked by CEO: TL cannot override.", fontSize = 10.sp, color = CeoPurple)
              }
            }
          }
        }

        if (selectedGroupEvents.isNotEmpty()) {
          selectedGroupEvents.forEach { ev ->
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = TeamLeadIndigoLight.copy(alpha = 0.5f),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(8.dp)) {
                Text("Group Event: ${ev.title}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TeamLeadIndigo)
                Text("Remark: ${ev.remark} • By ${ev.addedByTlName}", fontSize = 11.sp, color = TextSecondary)
              }
            }
          }
        }

        if (approvedLeavesOnDate.isNotEmpty()) {
          Text("Colleagues on Approved Leave:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
          approvedLeavesOnDate.forEach { leave ->
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              LeaveTypeBadge(leave.leaveType)
              Text("${leave.userName} (${leave.groupName})", fontSize = 11.sp, color = TextPrimary)
            }
          }
        } else if (selectedHoliday == null && selectedGroupEvents.isEmpty()) {
          Text("Standard Working Day • Normal group attendance scheduled.", fontSize = 11.sp, color = TextSecondary)
        }
      }
    }
  }
}

@Composable
private fun LegendDot(label: String, color: Color) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(4.dp)
  ) {
    Box(
      modifier = Modifier
        .size(8.dp)
        .clip(CircleShape)
        .background(color)
    )
    Text(label, fontSize = 10.sp, color = TextSecondary)
  }
}

@Composable
fun QuickChatScreen(
  repository: LeaveDeskRepository,
  modifier: Modifier = Modifier,
  initialThreadId: String? = null
) {
  val currentUser by repository.currentUser.collectAsState()
  val allMessages by repository.chatMessages.collectAsState()
  val availableThreads = remember(currentUser, allMessages) {
    repository.getAvailableChatThreads(currentUser)
  }

  var selectedThreadId by remember(availableThreads) {
    mutableStateOf(
      initialThreadId ?: availableThreads.firstOrNull { !it.isLocked }?.threadId ?: availableThreads.first().threadId
    )
  }

  var messageInput by remember { mutableStateOf("") }
  var attachedProof by remember { mutableStateOf<LeaveProof?>(null) }
  var showAttachmentDialog by remember { mutableStateOf(false) }
  var viewingAttachment by remember { mutableStateOf<LeaveProof?>(null) }

  val activeThread = remember(availableThreads, selectedThreadId) {
    availableThreads.find { it.threadId == selectedThreadId } ?: availableThreads.first()
  }

  val threadMessages = remember(allMessages, selectedThreadId) {
    allMessages.filter { it.threadId == selectedThreadId }.sortedBy { it.timestamp }
  }

  // Document Viewer Modal
  viewingAttachment?.let { proof ->
    AlertDialog(
      onDismissRequest = { viewingAttachment = null },
      title = {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Icon(Icons.Default.AttachFile, contentDescription = null, tint = LocalRoleTheme.current.accent)
          Text(proof.fileName, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = NeutralSurface,
            border = BorderStroke(1.dp, CardBorder),
            modifier = Modifier
              .fillMaxWidth()
              .height(140.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(
                  imageVector = if (proof.fileType.equals("PDF", ignoreCase = true)) Icons.Default.Description else Icons.Default.Image,
                  contentDescription = null,
                  tint = LocalRoleTheme.current.accent,
                  modifier = Modifier.size(36.dp)
                )
                Text("Verified Corporate Attachment", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text("${proof.fileType} • ${proof.fileSizeStr}", fontSize = 11.sp, color = TextSecondary)
                Text("Document signed & stored securely in LeaveDesk", fontSize = 10.sp, color = TextMuted)
              }
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = { viewingAttachment = null },
          colors = ButtonDefaults.buttonColors(containerColor = LocalRoleTheme.current.accent)
        ) {
          Text("Close")
        }
      }
    )
  }

  // Attachment Picker Modal
  if (showAttachmentDialog) {
    AlertDialog(
      onDismissRequest = { showAttachmentDialog = false },
      title = { Text("Select Attachment Proof", fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("Select evidence or proof to attach to this message:", fontSize = 12.sp, color = TextSecondary)

          val presets = listOf(
            LeaveProof("Medical_Certificate_Hospital.pdf", "PDF", "1.4 MB"),
            LeaveProof("Flight_Booking_Tahoe.pdf", "PDF", "1.2 MB"),
            LeaveProof("Client_Signoff_Confirmation.pdf", "PDF", "420 KB"),
            LeaveProof("Sprint_Handover_Checklist.docx", "DOCX", "350 KB"),
            LeaveProof("Executive_Handover_Guidelines.pdf", "PDF", "420 KB")
          )

          presets.forEach { preset ->
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (attachedProof?.fileName == preset.fileName) LocalRoleTheme.current.lightTint else NeutralSurface,
              border = BorderStroke(1.dp, if (attachedProof?.fileName == preset.fileName) LocalRoleTheme.current.accent else CardBorder),
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  attachedProof = preset
                  showAttachmentDialog = false
                }
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Icon(Icons.Default.AttachFile, contentDescription = null, tint = LocalRoleTheme.current.accent, modifier = Modifier.size(18.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(preset.fileName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                  Text("${preset.fileType} • ${preset.fileSizeStr}", fontSize = 10.sp, color = TextSecondary)
                }
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showAttachmentDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text("Corporate Chat & Queries", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
      Surface(
        shape = RoundedCornerShape(6.dp),
        color = LocalRoleTheme.current.lightTint
      ) {
        Text(
          text = currentUser.role.displayName,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = LocalRoleTheme.current.accent,
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
      }
    }

    // Thread selector chips
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      availableThreads.forEach { thread ->
        val isSelected = selectedThreadId == thread.threadId
        FilterChip(
          selected = isSelected,
          onClick = { selectedThreadId = thread.threadId },
          leadingIcon = {
            if (thread.isLocked) {
              Icon(Icons.Default.Lock, contentDescription = "Locked", modifier = Modifier.size(14.dp), tint = TextMuted)
            } else if (thread.role != null) {
              Box(
                modifier = Modifier
                  .size(8.dp)
                  .clip(CircleShape)
                  .background(if (thread.role == UserRole.CEO) CeoPurple else if (thread.role == UserRole.TEAM_LEAD) TeamLeadIndigo else EmployeeTeal)
              )
            } else {
              Icon(Icons.Default.Tag, contentDescription = null, modifier = Modifier.size(14.dp))
            }
          },
          label = { Text(thread.title, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) }
        )
      }
    }

    // Active Thread Header Card
    Card(
      shape = RoundedCornerShape(10.dp),
      colors = CardDefaults.cardColors(containerColor = Color.White),
      border = BorderStroke(1.dp, CardBorder),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(activeThread.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            activeThread.role?.let { RoleBadge(it) }
          }
          Text(activeThread.subtitle, fontSize = 11.sp, color = TextSecondary)
        }

        if (activeThread.isLocked) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = StatusRejectedBg
          ) {
            Text(
              text = "Locked",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = StatusRejectedRed,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }
      }
    }

    // Messages list
    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth(),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      if (threadMessages.isEmpty()) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 32.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = if (activeThread.isLocked) activeThread.lockReason ?: "Thread is currently locked."
              else "No messages in this channel yet. Type below to start the conversation.",
              fontSize = 12.sp,
              color = TextMuted
            )
          }
        }
      }

      items(threadMessages, key = { it.id }) { msg ->
        val isMe = msg.senderId == currentUser.id
        val alignment = if (isMe) Alignment.End else Alignment.Start

        Column(
          modifier = Modifier.fillMaxWidth(),
          horizontalAlignment = alignment
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            RoleBadge(msg.senderRole)
            Text(msg.senderName, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = TextSecondary)
            Text(msg.timestamp.format(DateTimeFormatter.ofPattern("HH:mm")), fontSize = 9.sp, color = TextMuted)
          }

          // Message bubble
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = when {
              msg.isOfficialQuery -> CeoPurpleLight
              msg.isOfficialDecision -> StatusRejectedBg.copy(alpha = 0.5f)
              isMe -> LocalRoleTheme.current.lightTint
              else -> Color.White
            },
            border = BorderStroke(
              1.dp,
              when {
                msg.isOfficialQuery -> CeoPurple
                msg.isOfficialDecision -> StatusRejectedRed
                isMe -> LocalRoleTheme.current.accent.copy(alpha = 0.4f)
                else -> CardBorder
              }
            ),
            modifier = Modifier.widthIn(max = 300.dp)
          ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              if (msg.isOfficialQuery) {
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = CeoPurple
                ) {
                  Text(
                    text = "OFFICIAL APPROVAL QUERY",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }

              if (msg.isOfficialDecision) {
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = StatusRejectedRed
                ) {
                  Text(
                    text = "EXECUTIVE DECISION",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }

              Text(
                text = msg.text,
                fontSize = 13.sp,
                color = TextPrimary
              )

              // Attached file inside chat bubble
              msg.attachment?.let { att ->
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = Color.White.copy(alpha = 0.8f),
                  border = BorderStroke(1.dp, CardBorder),
                  modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewingAttachment = att }
                ) {
                  Row(
                    modifier = Modifier.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                  ) {
                    Icon(Icons.Default.AttachFile, contentDescription = null, tint = LocalRoleTheme.current.accent, modifier = Modifier.size(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                      Text(att.fileName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                      Text("${att.fileType} • ${att.fileSizeStr} • Tap to view", fontSize = 10.sp, color = TextMuted)
                    }
                  }
                }
              }
            }
          }
        }
      }
    }

    // Input bar
    if (activeThread.isLocked) {
      Surface(
        shape = RoundedCornerShape(8.dp),
        color = StatusRejectedBg,
        border = BorderStroke(1.dp, StatusRejectedRed.copy(alpha = 0.3f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Icon(Icons.Default.Lock, contentDescription = null, tint = StatusRejectedRed, modifier = Modifier.size(16.dp))
          Text(
            text = activeThread.lockReason ?: "Communication channel is locked.",
            fontSize = 11.sp,
            color = StatusRejectedText
          )
        }
      }
    } else {
      Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        // Active attachment chip before sending
        attachedProof?.let { att ->
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = LocalRoleTheme.current.lightTint,
            border = BorderStroke(1.dp, LocalRoleTheme.current.accent),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(Icons.Default.AttachFile, contentDescription = null, tint = LocalRoleTheme.current.accent, modifier = Modifier.size(14.dp))
                Text("Ready to send: ${att.fileName} (${att.fileSizeStr})", fontSize = 11.sp, color = LocalRoleTheme.current.accent, fontWeight = FontWeight.SemiBold)
              }
              IconButton(onClick = { attachedProof = null }, modifier = Modifier.size(20.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Remove", tint = LocalRoleTheme.current.accent, modifier = Modifier.size(14.dp))
              }
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          IconButton(
            onClick = { showAttachmentDialog = true },
            modifier = Modifier.size(40.dp)
          ) {
            Icon(Icons.Default.AttachFile, contentDescription = "Attach Document", tint = LocalRoleTheme.current.accent)
          }

          OutlinedTextField(
            value = messageInput,
            onValueChange = { messageInput = it },
            placeholder = { Text("Reply or query response...") },
            modifier = Modifier
              .weight(1f)
              .testTag("chat_input_field"),
            singleLine = true
          )

          IconButton(
            onClick = {
              repository.sendChatMessage(
                sender = currentUser,
                text = messageInput,
                threadId = selectedThreadId,
                attachment = attachedProof,
                relatedRequestId = activeThread.relatedRequestId
              )
              messageInput = ""
              attachedProof = null
            },
            enabled = messageInput.isNotBlank() || attachedProof != null,
            modifier = Modifier.testTag("send_chat_message_btn")
          ) {
            Icon(Icons.Default.Send, contentDescription = "Send", tint = LocalRoleTheme.current.accent)
          }
        }
      }
    }
  }
}

@Composable
fun NotificationsScreen(
  repository: LeaveDeskRepository,
  modifier: Modifier = Modifier
) {
  val currentUser by repository.currentUser.collectAsState()
  val allNotifications by repository.notifications.collectAsState()

  val myNotifications = remember(allNotifications, currentUser) {
    allNotifications.filter {
      it.recipientUserId == currentUser.id || it.recipientUserId == "ALL"
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text("Notifications", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
      TextButton(onClick = { repository.markAllNotificationsAsRead(currentUser.id) }) {
        Text("Mark all read", fontSize = 12.sp)
      }
    }

    if (myNotifications.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        contentAlignment = Alignment.Center
      ) {
        Text("No notifications yet.", color = TextMuted)
      }
    } else {
      LazyColumn(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        items(myNotifications, key = { it.id }) { notif ->
          val icon = when (notif.type) {
            NotificationType.NEW_REQUEST -> Icons.Default.AddComment
            NotificationType.DECISION -> Icons.Default.CheckCircle
            NotificationType.QUERY -> Icons.Default.HelpOutline
            NotificationType.REMINDER_24H -> Icons.Default.Schedule
            NotificationType.ESCALATION_48H -> Icons.Default.NotificationImportant
            NotificationType.CALENDAR_CHANGE -> Icons.Default.CalendarMonth
            NotificationType.CANCEL_CONFIRMATION -> Icons.Default.Cancel
            NotificationType.BACKUP_ASSIGNED -> Icons.Default.PersonOutline
            NotificationType.EMERGENCY_MAIL -> Icons.Default.Mail
          }

          val tintColor = when (notif.type) {
            NotificationType.DECISION -> StatusApprovedGreen
            NotificationType.ESCALATION_48H, NotificationType.EMERGENCY_MAIL -> StatusRejectedRed
            NotificationType.QUERY -> CeoPurple
            NotificationType.REMINDER_24H -> StatusPendingAmber
            else -> EmployeeTeal
          }

          Card(
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = if (notif.isRead) Color.White else Color(0xFFF0FDF4)),
            border = BorderStroke(1.dp, CardBorder),
            modifier = Modifier
              .fillMaxWidth()
              .clickable { repository.markNotificationAsRead(notif.id) }
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
              verticalAlignment = Alignment.Top
            ) {
              Box(
                modifier = Modifier
                  .size(34.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .background(tintColor.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(icon, contentDescription = null, tint = tintColor, modifier = Modifier.size(18.dp))
              }

              Column(modifier = Modifier.weight(1f)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(notif.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                  Text(
                    notif.timestamp.format(DateTimeFormatter.ofPattern("HH:mm")),
                    fontSize = 10.sp,
                    color = TextMuted
                  )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(notif.message, fontSize = 11.sp, color = TextSecondary)
              }
            }
          }
        }
      }
    }
  }
}
